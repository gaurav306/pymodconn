# mod_seq2seq_conn

mod_seq2seq_conn = modular sequence to sequence control oriented neural networks

## Instructions

1. Install:

```
pip install mod_seq2seq_conn
```

2. Usage:
Download congifuration file from tests_usage\ in the github repository https://github.com/gaurav306/mod_seq2seq_conn

